﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChapeauModel
{
    public enum PaymentMethod
    {
        Cash = 1, Debit, Credit
    }
}

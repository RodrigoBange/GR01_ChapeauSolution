﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChapeauModel
{
    public enum MenuCategory
    {
        Lunch = 1, Dinner, Drinks
    }
}

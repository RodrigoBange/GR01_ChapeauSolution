﻿namespace ChapeauUI.Components
{
    partial class C_Table_Order
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_TableOrder = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btn_OrderServed10 = new System.Windows.Forms.Button();
            this.lbl_OrderItems10 = new System.Windows.Forms.Label();
            this.lbl_TableTime10 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btn_OrderServed9 = new System.Windows.Forms.Button();
            this.lbl_OrderItems9 = new System.Windows.Forms.Label();
            this.lbl_TableTime9 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_OrderServed8 = new System.Windows.Forms.Button();
            this.lbl_OrderItems8 = new System.Windows.Forms.Label();
            this.lbl_TableTime8 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_OrderServed7 = new System.Windows.Forms.Button();
            this.lbl_OrderItems7 = new System.Windows.Forms.Label();
            this.lbl_TableTime7 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_OrderServed6 = new System.Windows.Forms.Button();
            this.lbl_OrderItems6 = new System.Windows.Forms.Label();
            this.lbl_TableTime6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_OrderServed5 = new System.Windows.Forms.Button();
            this.lbl_OrderItems5 = new System.Windows.Forms.Label();
            this.lbl_TableTime5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_OrderItems4 = new System.Windows.Forms.Label();
            this.lbl_TableTime4 = new System.Windows.Forms.Label();
            this.btn_OrderServed4 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_OrderItems3 = new System.Windows.Forms.Label();
            this.btn_OrderServed3 = new System.Windows.Forms.Button();
            this.lbl_TableTime3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_OrderServed2 = new System.Windows.Forms.Button();
            this.lbl_OrderItems2 = new System.Windows.Forms.Label();
            this.lbl_TableTime2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_OrderItems1 = new System.Windows.Forms.Label();
            this.btn_OrderServed1 = new System.Windows.Forms.Button();
            this.lbl_TableTime1 = new System.Windows.Forms.Label();
            this.pnl_TableOrder.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_TableOrder
            // 
            this.pnl_TableOrder.AutoSize = true;
            this.pnl_TableOrder.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnl_TableOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.pnl_TableOrder.Controls.Add(this.panel10);
            this.pnl_TableOrder.Controls.Add(this.panel9);
            this.pnl_TableOrder.Controls.Add(this.panel8);
            this.pnl_TableOrder.Controls.Add(this.panel7);
            this.pnl_TableOrder.Controls.Add(this.panel6);
            this.pnl_TableOrder.Controls.Add(this.panel5);
            this.pnl_TableOrder.Controls.Add(this.panel4);
            this.pnl_TableOrder.Controls.Add(this.panel3);
            this.pnl_TableOrder.Controls.Add(this.panel2);
            this.pnl_TableOrder.Controls.Add(this.panel1);
            this.pnl_TableOrder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_TableOrder.Location = new System.Drawing.Point(0, 0);
            this.pnl_TableOrder.MaximumSize = new System.Drawing.Size(300, 0);
            this.pnl_TableOrder.MinimumSize = new System.Drawing.Size(300, 150);
            this.pnl_TableOrder.Name = "pnl_TableOrder";
            this.pnl_TableOrder.Size = new System.Drawing.Size(300, 660);
            this.pnl_TableOrder.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.AutoSize = true;
            this.panel10.Controls.Add(this.btn_OrderServed10);
            this.panel10.Controls.Add(this.lbl_OrderItems10);
            this.panel10.Controls.Add(this.lbl_TableTime10);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 594);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(300, 66);
            this.panel10.TabIndex = 65;
            // 
            // btn_OrderServed10
            // 
            this.btn_OrderServed10.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed10.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed10.Location = new System.Drawing.Point(253, 5);
            this.btn_OrderServed10.Name = "btn_OrderServed10";
            this.btn_OrderServed10.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed10.TabIndex = 55;
            this.btn_OrderServed10.UseVisualStyleBackColor = false;
            this.btn_OrderServed10.Click += new System.EventHandler(this.btn_OrderServed10_Click);
            // 
            // lbl_OrderItems10
            // 
            this.lbl_OrderItems10.AutoSize = true;
            this.lbl_OrderItems10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems10.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems10.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems10.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems10.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems10.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems10.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems10.Name = "lbl_OrderItems10";
            this.lbl_OrderItems10.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems10.TabIndex = 26;
            // 
            // lbl_TableTime10
            // 
            this.lbl_TableTime10.AutoSize = true;
            this.lbl_TableTime10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime10.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime10.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime10.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime10.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime10.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime10.Name = "lbl_TableTime10";
            this.lbl_TableTime10.Size = new System.Drawing.Size(189, 33);
            this.lbl_TableTime10.TabIndex = 45;
            this.lbl_TableTime10.Text = "Table 10 - 00:00";
            // 
            // panel9
            // 
            this.panel9.AutoSize = true;
            this.panel9.Controls.Add(this.btn_OrderServed9);
            this.panel9.Controls.Add(this.lbl_OrderItems9);
            this.panel9.Controls.Add(this.lbl_TableTime9);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 528);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(300, 66);
            this.panel9.TabIndex = 64;
            // 
            // btn_OrderServed9
            // 
            this.btn_OrderServed9.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed9.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed9.Location = new System.Drawing.Point(253, 6);
            this.btn_OrderServed9.Name = "btn_OrderServed9";
            this.btn_OrderServed9.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed9.TabIndex = 54;
            this.btn_OrderServed9.UseVisualStyleBackColor = false;
            this.btn_OrderServed9.Click += new System.EventHandler(this.btn_OrderServed9_Click);
            // 
            // lbl_OrderItems9
            // 
            this.lbl_OrderItems9.AutoSize = true;
            this.lbl_OrderItems9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems9.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems9.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems9.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems9.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems9.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems9.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems9.Name = "lbl_OrderItems9";
            this.lbl_OrderItems9.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems9.TabIndex = 29;
            // 
            // lbl_TableTime9
            // 
            this.lbl_TableTime9.AutoSize = true;
            this.lbl_TableTime9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime9.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime9.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime9.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime9.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime9.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime9.Name = "lbl_TableTime9";
            this.lbl_TableTime9.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime9.TabIndex = 44;
            this.lbl_TableTime9.Text = "Table 9 - 00:00";
            // 
            // panel8
            // 
            this.panel8.AutoSize = true;
            this.panel8.Controls.Add(this.btn_OrderServed8);
            this.panel8.Controls.Add(this.lbl_OrderItems8);
            this.panel8.Controls.Add(this.lbl_TableTime8);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 462);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(300, 66);
            this.panel8.TabIndex = 63;
            // 
            // btn_OrderServed8
            // 
            this.btn_OrderServed8.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed8.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed8.Location = new System.Drawing.Point(253, 5);
            this.btn_OrderServed8.Name = "btn_OrderServed8";
            this.btn_OrderServed8.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed8.TabIndex = 53;
            this.btn_OrderServed8.UseVisualStyleBackColor = false;
            this.btn_OrderServed8.Click += new System.EventHandler(this.btn_OrderServed8_Click);
            // 
            // lbl_OrderItems8
            // 
            this.lbl_OrderItems8.AutoSize = true;
            this.lbl_OrderItems8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems8.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems8.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems8.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems8.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems8.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems8.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems8.Name = "lbl_OrderItems8";
            this.lbl_OrderItems8.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems8.TabIndex = 30;
            // 
            // lbl_TableTime8
            // 
            this.lbl_TableTime8.AutoSize = true;
            this.lbl_TableTime8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime8.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime8.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime8.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime8.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime8.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime8.Name = "lbl_TableTime8";
            this.lbl_TableTime8.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime8.TabIndex = 43;
            this.lbl_TableTime8.Text = "Table 8 - 00:00";
            // 
            // panel7
            // 
            this.panel7.AutoSize = true;
            this.panel7.Controls.Add(this.btn_OrderServed7);
            this.panel7.Controls.Add(this.lbl_OrderItems7);
            this.panel7.Controls.Add(this.lbl_TableTime7);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 396);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(300, 66);
            this.panel7.TabIndex = 62;
            // 
            // btn_OrderServed7
            // 
            this.btn_OrderServed7.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed7.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed7.Location = new System.Drawing.Point(253, 6);
            this.btn_OrderServed7.Name = "btn_OrderServed7";
            this.btn_OrderServed7.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed7.TabIndex = 52;
            this.btn_OrderServed7.UseVisualStyleBackColor = false;
            this.btn_OrderServed7.Click += new System.EventHandler(this.btn_OrderServed7_Click);
            // 
            // lbl_OrderItems7
            // 
            this.lbl_OrderItems7.AutoSize = true;
            this.lbl_OrderItems7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems7.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems7.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems7.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems7.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems7.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems7.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems7.Name = "lbl_OrderItems7";
            this.lbl_OrderItems7.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems7.TabIndex = 31;
            // 
            // lbl_TableTime7
            // 
            this.lbl_TableTime7.AutoSize = true;
            this.lbl_TableTime7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime7.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime7.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime7.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime7.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime7.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime7.Name = "lbl_TableTime7";
            this.lbl_TableTime7.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime7.TabIndex = 42;
            this.lbl_TableTime7.Text = "Table 7 - 00:00";
            // 
            // panel6
            // 
            this.panel6.AutoSize = true;
            this.panel6.Controls.Add(this.btn_OrderServed6);
            this.panel6.Controls.Add(this.lbl_OrderItems6);
            this.panel6.Controls.Add(this.lbl_TableTime6);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 330);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(300, 66);
            this.panel6.TabIndex = 61;
            // 
            // btn_OrderServed6
            // 
            this.btn_OrderServed6.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed6.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed6.Location = new System.Drawing.Point(253, 6);
            this.btn_OrderServed6.Name = "btn_OrderServed6";
            this.btn_OrderServed6.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed6.TabIndex = 51;
            this.btn_OrderServed6.UseVisualStyleBackColor = false;
            this.btn_OrderServed6.Click += new System.EventHandler(this.btn_OrderServed6_Click);
            // 
            // lbl_OrderItems6
            // 
            this.lbl_OrderItems6.AutoSize = true;
            this.lbl_OrderItems6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems6.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems6.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems6.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems6.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems6.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems6.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems6.Name = "lbl_OrderItems6";
            this.lbl_OrderItems6.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems6.TabIndex = 32;
            // 
            // lbl_TableTime6
            // 
            this.lbl_TableTime6.AutoSize = true;
            this.lbl_TableTime6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime6.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime6.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime6.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime6.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime6.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime6.Name = "lbl_TableTime6";
            this.lbl_TableTime6.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime6.TabIndex = 41;
            this.lbl_TableTime6.Text = "Table 6 - 00:00";
            // 
            // panel5
            // 
            this.panel5.AutoSize = true;
            this.panel5.Controls.Add(this.btn_OrderServed5);
            this.panel5.Controls.Add(this.lbl_OrderItems5);
            this.panel5.Controls.Add(this.lbl_TableTime5);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 264);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(300, 66);
            this.panel5.TabIndex = 60;
            // 
            // btn_OrderServed5
            // 
            this.btn_OrderServed5.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed5.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed5.Location = new System.Drawing.Point(253, 5);
            this.btn_OrderServed5.Name = "btn_OrderServed5";
            this.btn_OrderServed5.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed5.TabIndex = 50;
            this.btn_OrderServed5.UseVisualStyleBackColor = false;
            this.btn_OrderServed5.Click += new System.EventHandler(this.btn_OrderServed5_Click);
            // 
            // lbl_OrderItems5
            // 
            this.lbl_OrderItems5.AutoSize = true;
            this.lbl_OrderItems5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems5.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems5.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems5.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems5.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems5.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems5.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems5.Name = "lbl_OrderItems5";
            this.lbl_OrderItems5.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems5.TabIndex = 33;
            // 
            // lbl_TableTime5
            // 
            this.lbl_TableTime5.AutoSize = true;
            this.lbl_TableTime5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime5.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime5.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime5.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime5.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime5.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime5.Name = "lbl_TableTime5";
            this.lbl_TableTime5.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime5.TabIndex = 40;
            this.lbl_TableTime5.Text = "Table 5 - 00:00";
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.Controls.Add(this.lbl_OrderItems4);
            this.panel4.Controls.Add(this.lbl_TableTime4);
            this.panel4.Controls.Add(this.btn_OrderServed4);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 198);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(300, 66);
            this.panel4.TabIndex = 59;
            // 
            // lbl_OrderItems4
            // 
            this.lbl_OrderItems4.AutoSize = true;
            this.lbl_OrderItems4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems4.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems4.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems4.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems4.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems4.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems4.Name = "lbl_OrderItems4";
            this.lbl_OrderItems4.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems4.TabIndex = 34;
            // 
            // lbl_TableTime4
            // 
            this.lbl_TableTime4.AutoSize = true;
            this.lbl_TableTime4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime4.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime4.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime4.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime4.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime4.Name = "lbl_TableTime4";
            this.lbl_TableTime4.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime4.TabIndex = 39;
            this.lbl_TableTime4.Text = "Table 4 - 00:00";
            // 
            // btn_OrderServed4
            // 
            this.btn_OrderServed4.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed4.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed4.Location = new System.Drawing.Point(253, 6);
            this.btn_OrderServed4.Name = "btn_OrderServed4";
            this.btn_OrderServed4.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed4.TabIndex = 49;
            this.btn_OrderServed4.UseVisualStyleBackColor = false;
            this.btn_OrderServed4.Click += new System.EventHandler(this.btn_OrderServed4_Click);
            // 
            // panel3
            // 
            this.panel3.AutoSize = true;
            this.panel3.Controls.Add(this.lbl_OrderItems3);
            this.panel3.Controls.Add(this.btn_OrderServed3);
            this.panel3.Controls.Add(this.lbl_TableTime3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 132);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 66);
            this.panel3.TabIndex = 58;
            // 
            // lbl_OrderItems3
            // 
            this.lbl_OrderItems3.AutoSize = true;
            this.lbl_OrderItems3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems3.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems3.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems3.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems3.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems3.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems3.Name = "lbl_OrderItems3";
            this.lbl_OrderItems3.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems3.TabIndex = 35;
            // 
            // btn_OrderServed3
            // 
            this.btn_OrderServed3.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed3.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed3.Location = new System.Drawing.Point(253, 6);
            this.btn_OrderServed3.Name = "btn_OrderServed3";
            this.btn_OrderServed3.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed3.TabIndex = 48;
            this.btn_OrderServed3.UseVisualStyleBackColor = false;
            this.btn_OrderServed3.Click += new System.EventHandler(this.btn_OrderServed3_Click);
            // 
            // lbl_TableTime3
            // 
            this.lbl_TableTime3.AutoSize = true;
            this.lbl_TableTime3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime3.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime3.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime3.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime3.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime3.Name = "lbl_TableTime3";
            this.lbl_TableTime3.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime3.TabIndex = 38;
            this.lbl_TableTime3.Text = "Table 3 - 00:00";
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.Controls.Add(this.btn_OrderServed2);
            this.panel2.Controls.Add(this.lbl_OrderItems2);
            this.panel2.Controls.Add(this.lbl_TableTime2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 66);
            this.panel2.TabIndex = 57;
            // 
            // btn_OrderServed2
            // 
            this.btn_OrderServed2.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed2.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed2.ForeColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed2.Location = new System.Drawing.Point(253, 6);
            this.btn_OrderServed2.Name = "btn_OrderServed2";
            this.btn_OrderServed2.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed2.TabIndex = 47;
            this.btn_OrderServed2.UseVisualStyleBackColor = false;
            this.btn_OrderServed2.Click += new System.EventHandler(this.btn_OrderServed2_Click);
            // 
            // lbl_OrderItems2
            // 
            this.lbl_OrderItems2.AutoSize = true;
            this.lbl_OrderItems2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems2.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems2.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems2.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems2.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems2.Name = "lbl_OrderItems2";
            this.lbl_OrderItems2.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems2.TabIndex = 28;
            // 
            // lbl_TableTime2
            // 
            this.lbl_TableTime2.AutoSize = true;
            this.lbl_TableTime2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime2.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime2.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime2.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime2.Name = "lbl_TableTime2";
            this.lbl_TableTime2.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime2.TabIndex = 37;
            this.lbl_TableTime2.Text = "Table 2 - 00:00";
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.lbl_OrderItems1);
            this.panel1.Controls.Add(this.btn_OrderServed1);
            this.panel1.Controls.Add(this.lbl_TableTime1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 66);
            this.panel1.TabIndex = 56;
            // 
            // lbl_OrderItems1
            // 
            this.lbl_OrderItems1.AutoSize = true;
            this.lbl_OrderItems1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_OrderItems1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_OrderItems1.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_OrderItems1.ForeColor = System.Drawing.Color.White;
            this.lbl_OrderItems1.Location = new System.Drawing.Point(0, 33);
            this.lbl_OrderItems1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_OrderItems1.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_OrderItems1.Name = "lbl_OrderItems1";
            this.lbl_OrderItems1.Size = new System.Drawing.Size(0, 33);
            this.lbl_OrderItems1.TabIndex = 27;
            // 
            // btn_OrderServed1
            // 
            this.btn_OrderServed1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_OrderServed1.BackColor = System.Drawing.Color.Transparent;
            this.btn_OrderServed1.BackgroundImage = global::ChapeauUI.Properties.Resources.cross1;
            this.btn_OrderServed1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_OrderServed1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_OrderServed1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_OrderServed1.Location = new System.Drawing.Point(253, 5);
            this.btn_OrderServed1.Name = "btn_OrderServed1";
            this.btn_OrderServed1.Size = new System.Drawing.Size(29, 30);
            this.btn_OrderServed1.TabIndex = 46;
            this.btn_OrderServed1.UseVisualStyleBackColor = false;
            this.btn_OrderServed1.Click += new System.EventHandler(this.btn_OrderServed1_Click);
            // 
            // lbl_TableTime1
            // 
            this.lbl_TableTime1.AutoSize = true;
            this.lbl_TableTime1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.lbl_TableTime1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_TableTime1.Font = new System.Drawing.Font("Calibri", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_TableTime1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(151)))), ((int)(((byte)(169)))));
            this.lbl_TableTime1.Location = new System.Drawing.Point(0, 0);
            this.lbl_TableTime1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_TableTime1.MaximumSize = new System.Drawing.Size(300, 0);
            this.lbl_TableTime1.Name = "lbl_TableTime1";
            this.lbl_TableTime1.Size = new System.Drawing.Size(175, 33);
            this.lbl_TableTime1.TabIndex = 36;
            this.lbl_TableTime1.Text = "Table 1 - 00:00";
            // 
            // C_Table_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(27)))), ((int)(((byte)(45)))));
            this.Controls.Add(this.pnl_TableOrder);
            this.DoubleBuffered = true;
            this.MaximumSize = new System.Drawing.Size(300, 0);
            this.Name = "C_Table_Order";
            this.Size = new System.Drawing.Size(300, 660);
            this.pnl_TableOrder.ResumeLayout(false);
            this.pnl_TableOrder.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_TableOrder;
        private System.Windows.Forms.Label lbl_OrderItems10;
        private System.Windows.Forms.Label lbl_OrderItems9;
        private System.Windows.Forms.Label lbl_OrderItems8;
        private System.Windows.Forms.Label lbl_OrderItems7;
        private System.Windows.Forms.Label lbl_OrderItems6;
        private System.Windows.Forms.Label lbl_OrderItems5;
        private System.Windows.Forms.Label lbl_OrderItems4;
        private System.Windows.Forms.Label lbl_OrderItems3;
        private System.Windows.Forms.Label lbl_OrderItems2;
        private System.Windows.Forms.Label lbl_OrderItems1;
        private System.Windows.Forms.Label lbl_TableTime1;
        private System.Windows.Forms.Label lbl_TableTime2;
        private System.Windows.Forms.Label lbl_TableTime10;
        private System.Windows.Forms.Label lbl_TableTime9;
        private System.Windows.Forms.Label lbl_TableTime8;
        private System.Windows.Forms.Label lbl_TableTime7;
        private System.Windows.Forms.Label lbl_TableTime6;
        private System.Windows.Forms.Label lbl_TableTime5;
        private System.Windows.Forms.Label lbl_TableTime4;
        private System.Windows.Forms.Label lbl_TableTime3;
        private System.Windows.Forms.Button btn_OrderServed1;
        private System.Windows.Forms.Button btn_OrderServed10;
        private System.Windows.Forms.Button btn_OrderServed9;
        private System.Windows.Forms.Button btn_OrderServed8;
        private System.Windows.Forms.Button btn_OrderServed7;
        private System.Windows.Forms.Button btn_OrderServed6;
        private System.Windows.Forms.Button btn_OrderServed5;
        private System.Windows.Forms.Button btn_OrderServed4;
        private System.Windows.Forms.Button btn_OrderServed3;
        private System.Windows.Forms.Button btn_OrderServed2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
    }
}
